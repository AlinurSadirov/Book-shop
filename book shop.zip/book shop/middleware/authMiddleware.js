import jwt from "jsonwebtoken";

// 📌 Проверка токена (для всех авторизованных пользователей)
export const verifyToken = (req, res, next) => {
  const authHeader = req.headers.authorization;

  if (!authHeader || !authHeader.startsWith("Bearer ")) {
    return res.status(401).json({ message: "Нет токена, доступ запрещён" });
  }

  const token = authHeader.split(" ")[1];

  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    req.user = decoded; // { id: ..., isAdmin: ... }
    next();
  } catch (err) {
    res.status(403).json({ message: "Недействительный токен" });
  }
};

// 📌 Проверка прав админа
export const verifyAdmin = (req, res, next) => {
  verifyToken(req, res, () => {
    if (req.user.isAdmin) {
      next();
    } else {
      res.status(403).json({ message: "Только админ имеет доступ" });
    }
  });
};
