import express from "express";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import User from "../models/user.js";

const router = express.Router();

// 📌 Регистрация
router.post("/register", async (req, res) => {
  try {
    const { username, email, password } = req.body;

    // Проверяем, есть ли пользователь
    const existingUser = await User.findOne({ email });
    if (existingUser) return res.status(400).json({ message: "Пользователь уже существует" });

    // Хэшируем пароль
    const hashedPassword = await bcrypt.hash(password, 10);

    const newUser = new User({
      username,
      email,
      password: hashedPassword,
    });

    await newUser.save();
    res.status(201).json({ message: "✅ Пользователь создан" });
  } catch (err) {
    res.status(500).json({ message: "Ошибка сервера", error: err.message });
  }
});

// 📌 Логин
router.post("/login", async (req, res) => {
  try {
    const { email, password } = req.body;

    // Проверяем пользователя
    const user = await User.findOne({ email });
    if (!user) return res.status(400).json({ message: "Пользователь не найден" });

    // Проверяем пароль
    const isPasswordCorrect = await bcrypt.compare(password, user.password);
    if (!isPasswordCorrect) return res.status(400).json({ message: "Неверный пароль" });

    // Генерация JWT
    const token = jwt.sign(
      { id: user._id, isAdmin: user.isAdmin },
      process.env.JWT_SECRET,
      { expiresIn: "1d" }
    );

    res.json({ message: "✅ Успешный вход", token, user });
  } catch (err) {
    res.status(500).json({ message: "Ошибка сервера", error: err.message });
  }
});

export default router;
