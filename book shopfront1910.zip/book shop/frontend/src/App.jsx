import Header from "./components/Header";
import Home from "./pages/Home";

function App() {
  return (
    <div className="min-h-screen flex flex-col bg-gray-100 text-gray-900">
      <Header />

      {/* Контент главной страницы */}
      <main className="flex flex-col items-center justify-center flex-grow">
        <Home />
      </main>
    </div>
  );
}

export default App;


