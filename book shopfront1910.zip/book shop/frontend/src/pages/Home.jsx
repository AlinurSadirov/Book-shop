import BookCard from "../components/Bookcard";

export default function Home() {
  const books = [
    {
      title: "Жестяной барабан",
      author: "Гюнтер Грасс",
      cover: "https://alpinabook.ru/upload/iblock/994/m5rqvmvedttlbbeb6qzj5ck2z03amx85/face_zhestyanojbaraban.jpg",
    },
    {
      title: "Скорбь Сатаны",
      author: "Мария Корелли",
      cover: "https://fantasy-worlds.net/img/full/241/24123.jpg",
    },
    {
      title: "Бесы",
      author: "Фёдор Достоевский",
      cover: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSwrlDKc-qRsp9r1rxVbTuXbvgUki4WZa6R8g&s",
    },
    {
      title: "Лягушки",
      author: "Мо Янь",
      cover: "https://imo10.labirint.ru/books/732949/cover.jpg/242-0",
    },
    {
      title: "Идеальный муж",
      author: "Оскар Уайльд",
      cover: "https://anylang.net/sites/default/files/covers/ideal-husband.jpg",
    },
    {
      title: "О женщинах",
      author: "Сьюзен Сонтанг",
      cover: "https://simg.marwin.kz/media/catalog/product/s/o/sontag_s_o_zhenshchinakh.jpg",
    },
    {
      title: "Искусство войны",
      author: "Сунь Цзы",
      cover: "https://simg.marwin.kz/media/catalog/product/c/o/cover1_69_1079.jpg",
    },
    {
      title: "Джамиля",
      author: "Чингиз Айтматов",
      cover: "https://resources.cdn-kaspi.kz/img/m/p/h7f/h36/68976863936542.jpg?format=gallery-large",
    },
    {
      title: "Идиот",
      author: "Фёдор Достоевский",
      cover: "https://simg.marwin.kz/media/catalog/product/cache/41deb699a7fea062a8915debbbb0442c/c/o/dostoevskiy_f_m_idiot_12.jpg",
    },
    {
      title: "Гранатовый браслет",
      author: "Александр Куприн",
      cover: "https://cdn.litres.ru/pub/c/cover_h400/18394048.jpg",
    },
    {
      title: "Бойцовский Клуб",
      author: "Чак Паланик",
      cover: "https://imo10.labirint.ru/books/613023/cover.jpg/484-0",
    },
    {
      title: "Парфюмер",
      author: "Патрик Зюскинд",
      cover: "https://img.labirint.ru/images/comments_pic/1237/01labors91347691787.jpg",
    },
  ];

  return (
    <div className="min-h-screen bg-gray-50 p-10">
      <h1 className="text-3xl font-bold mb-8 text-center">Каталог книг</h1>

      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-6 justify-items-center">
        {books.map((book, index) => (
          <div
            key={index}
            className="bg-white shadow-md rounded-lg overflow-hidden w-[160px] transition-transform transform hover:scale-105"
          >
            <div className="w-[160px] h-[220px] overflow-hidden flex items-center justify-center bg-gray-100">
              <img
                src={book.cover}
                alt={book.title}
                className="w-[160px] h-[220px] object-cover"
              />
            </div>
            <div className="p-3 text-center">
              <h2 className="text-sm font-semibold">{book.title}</h2>
              <p className="text-xs text-gray-600">{book.author}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}