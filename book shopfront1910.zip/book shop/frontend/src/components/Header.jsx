export default function Header() {
  return (
    <header className="w-full bg-white shadow-md">
      <div className="max-w-6xl mx-auto flex justify-between items-center px-6 py-4">
        {/* Логотип */}
        <h1 className="text-2xl font-bold text-gray-800">📚 Book Shop</h1>

        {/* Кнопка Авторизация */}
        <button className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition">
          Авторизация
        </button>
      </div>
    </header>
  );
}
