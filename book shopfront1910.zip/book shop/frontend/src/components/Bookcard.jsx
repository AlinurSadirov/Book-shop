export default function BookCard({ title, author, cover }) {
  return (
    <div className="bg-white rounded-lg shadow-md p-4 flex flex-col items-center transition-transform hover:scale-105 w-44 sm:w-48">
      <div className="w-full h-48 flex justify-center items-center overflow-hidden rounded-md bg-gray-100">
        <img
          src={cover}
          alt={title}
          className="max-w-full max-h-full object-contain"
          loading="lazy"
        />
      </div>
      <h3 className="text-sm font-semibold text-center mt-3 line-clamp-2">{title}</h3>
      <p className="text-xs text-gray-500 text-center">{author}</p>
    </div>
  );
}
