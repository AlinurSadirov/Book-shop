import express from "express";
import User from "../models/user.js";
import Book from "../models/Book.js";
import { verifyToken } from "../middleware/authMiddleware.js";

const router = express.Router();

// 📌 Получить профиль пользователя
router.get("/me", verifyToken, async (req, res) => {
  try {
    const user = await User.findById(req.user.id)
      .populate("favorites")
      .populate("readingList");
    res.json(user);
  } catch (err) {
    res.status(500).json({ message: "Ошибка профиля", error: err.message });
  }
});

// 📌 Добавить книгу в избранное
router.post("/favorites/:bookId", verifyToken, async (req, res) => {
  try {
    const user = await User.findById(req.user.id);
    if (!user.favorites.includes(req.params.bookId)) {
      user.favorites.push(req.params.bookId);
      await user.save();
    }
    res.json({ message: "Книга добавлена в избранное", favorites: user.favorites });
  } catch (err) {
    res.status(500).json({ message: "Ошибка добавления", error: err.message });
  }
});

// 📌 Удалить книгу из избранного
router.delete("/favorites/:bookId", verifyToken, async (req, res) => {
  try {
    const user = await User.findById(req.user.id);
    user.favorites = user.favorites.filter(id => id.toString() !== req.params.bookId);
    await user.save();
    res.json({ message: "Книга удалена из избранного", favorites: user.favorites });
  } catch (err) {
    res.status(500).json({ message: "Ошибка удаления", error: err.message });
  }
});

// 📌 Добавить книгу в список для чтения
router.post("/reading-list/:bookId", verifyToken, async (req, res) => {
  try {
    const user = await User.findById(req.user.id);
    if (!user.readingList.includes(req.params.bookId)) {
      user.readingList.push(req.params.bookId);
      await user.save();
    }
    res.json({ message: "Книга добавлена в список для чтения", readingList: user.readingList });
  } catch (err) {
    res.status(500).json({ message: "Ошибка добавления", error: err.message });
  }
});

// 📌 Удалить книгу из списка для чтения
router.delete("/reading-list/:bookId", verifyToken, async (req, res) => {
  try {
    const user = await User.findById(req.user.id);
    user.readingList = user.readingList.filter(id => id.toString() !== req.params.bookId);
    await user.save();
    res.json({ message: "Книга удалена из списка для чтения", readingList: user.readingList });
  } catch (err) {
    res.status(500).json({ message: "Ошибка удаления", error: err.message });
  }
});

export default router;
