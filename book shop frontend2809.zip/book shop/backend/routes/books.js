import express from "express";
import Book from "../models/Book.js";
import { verifyAdmin, verifyToken } from "../middleware/authMiddleware.js";

const router = express.Router();

// 📌 Получить все книги (доступно всем)
router.get("/", async (req, res) => {
  try {
    const { author, genre, year } = req.query;
    let filter = {};

    if (author) filter.author = author;
    if (genre) filter.genre = genre;
    if (year) filter.year = year;

    const books = await Book.find(filter);
    res.json(books);
  } catch (err) {
    res.status(500).json({ message: "Ошибка получения книг", error: err.message });
  }
});

// 📌 Добавить книгу (только админ)
router.post("/", verifyAdmin, async (req, res) => {
  try {
    const newBook = new Book(req.body);
    await newBook.save();
    res.status(201).json(newBook);
  } catch (err) {
    res.status(500).json({ message: "Ошибка добавления книги", error: err.message });
  }
});

// 📌 Добавить книгу в избранное (обычный пользователь)
router.post("/:id/favorite", verifyToken, async (req, res) => {
  try {
    const user = await User.findById(req.user.id);
    if (!user.favorites.includes(req.params.id)) {
      user.favorites.push(req.params.id);
      await user.save();
    }
    res.json({ message: "Книга добавлена в избранное" });
  } catch (err) {
    res.status(500).json({ message: "Ошибка добавления в избранное", error: err.message });
  }
});

// 📌 Получить одну книгу
router.post("/:id/favorite", verifyToken, async (req, res) => {
  try {
    const book = await Book.findById(req.params.id);
    if (!book) return res.status(404).json({ message: "Книга не найдена" });
    res.json(book);
  } catch (err) {
    res.status(500).json({ message: "Ошибка получения книги", error: err.message });
  }
});

// 📌 Обновить книгу
router.post("/", verifyAdmin, async (req, res) => {
  try {
    const updatedBook = await Book.findByIdAndUpdate(req.params.id, req.body, { new: true });
    res.json(updatedBook);
  } catch (err) {
    res.status(500).json({ message: "Ошибка обновления книги", error: err.message });
  }
});

// 📌 Удалить книгу
router.post("/", verifyAdmin, async (req, res) => {
  try {
    await Book.findByIdAndDelete(req.params.id);
    res.json({ message: "Книга удалена" });
  } catch (err) {
    res.status(500).json({ message: "Ошибка удаления книги", error: err.message });
  }
});

export default router;